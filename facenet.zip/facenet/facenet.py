from deepface.basemodels import Facenet
from io import BytesIO
from PIL import Image
import numpy as np
from deepface.commons import functions
import faiss

# loading the facenet model
model = Facenet.loadModel()

# loading the vector index
index = faiss.read_index(r'C:\Users\Lakshmi M\Desktop\facenet\vector.index')

def preprocess_image(data):
    # converting image into bytes
    img = Image.open(BytesIO(data))

    
    # converting img bytes into ARRAY
    img = np.array(img)

    # resizing the image,it will extract face features
    target_img =  functions.preprocess_face(img = img,target_size=(160,160),enforce_detection=False)

    # facenet model will predict the target img vectors
    target_img =  model.predict(target_img)[0,:]

    # faiss expects 2 dimensional matrix as float32 np array type.i have converted into float32 type
    target_img = np.array(target_img, dtype = 'f')

    # faiss expect 2d matrix, thats why dummy dimesion will be added.dimesion expansion
    target_img = np.expand_dims(target_img,axis = 0)

    #  finding the distance and neighbprs of targe_image
    distance ,neighbors = index.search(target_img,1)

    distance = distance[0]
    neighbors = neighbors[0]
    # returning the distance and neighbors
    return distance,neighbors


