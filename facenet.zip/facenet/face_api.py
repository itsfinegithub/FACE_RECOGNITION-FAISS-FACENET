from fastapi import FastAPI,File,UploadFile,HTTPException
import numpy as np
from facenet import preprocess_image
import logging
import time
import pandas as pd

# this file contain employee names
emp_name = pd.read_csv('emp_name.csv')


app = FastAPI()

@app.get('/')
def home():
    return {'welcome to facenet model'}

# loggingsky
FORMAT = '%(asctime)s %(levelname)s %(message)s'
logging.basicConfig(filename='mental.log',level = logging.INFO,format=FORMAT)


@app.post('/predict')
async def predict(file: UploadFile = File(...)):
    # it will accept extension which are mentioned below 
    if not file.filename.split(".")[-1] in ("jpg","jpeg","png"):
        raise HTTPException(status_code=400, detail = f'File \'{file.filename}\'is not an right extension of image')
    try:

        logging.info('got the image from the user')
        start = time.perf_counter()

        # preprocess the image and it will give the distance of neighbors 
        distance, neighbors = preprocess_image(await file.read())
    
    
        logging.info(f'successfully preprocessed')
        
        # threshold is 50
        if distance < 50:
            name = emp_name['emp_name'][neighbors]
        else:
            name = 'employee not in the database'

        end = time.perf_counter()
        logging.info(f'finished time is {end}-{start}')

        return name
    except:
        return 'something went wrong'












